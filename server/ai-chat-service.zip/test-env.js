require('dotenv').config();

console.log('DOUBAO_API_KEY:', process.env.DOUBAO_API_KEY);
console.log('DOUBAO_ENDPOINT:', process.env.DOUBAO_ENDPOINT);
console.log('DOUBAO_SECRET_KEY:', process.env.DOUBAO_SECRET_KEY);